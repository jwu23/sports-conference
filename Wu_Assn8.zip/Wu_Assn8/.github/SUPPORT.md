# Support

For personal support requests with HTML5 Boilerplate please use Stack Overflow
([`html5boilerplate`](https://stackoverflow.com/questions/tagged/html5boilerplate) tag).
  
Please check the respective repository/website for support regarding the code in
  [`.htaccess`](https://github.com/h5bp/server-configs-apache),
  [`jQuery`](https://jquery.org/support/),
  [`Modernizr`](https://modernizr.com/) or
  [`Normalize.css`](https://github.com/necolas/normalize.css).
