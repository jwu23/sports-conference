from operator import itemgetter

options = {
    "Workshop1": "Shooting",
    "Workshop2": "Dribbling",
    "Workshop3": "Defense",
    "Workshop4": "Passing",
    "Workshop5": "Setting",
    "Workshop6": "Blocking",
    "Workshop7": "Throwing",
    "Workshop8": "Tackling",
    "Workshop9": "Catching",
    "mealpack": "Full Meal Package",
    "dinnerday2": "Only dinner on day 2",
    "allconference": "All registrants of conference"
}


class Registrant(dict):
    keys = ["title", "firstname", "lastname", "address1", "address2", "city", "state", "zipcode", "email", "telephone", "billing-firstname", "billing-lastname", "card_csv", "exp-month", "exp-year", "card_number", "company", "position", "website", "session1", "session2", "session3", "meals", "date_of_registration"]


def getJSONdata():
    import json
    registrantList = []
    with open('registrant_data.json', 'r') as registrantData:
        dataObject = json.load(registrantData)
        for registrant in dataObject["registrants"]:
            nextRegistrant = Registrant(registrant)
            registrantList.append(nextRegistrant)
    return registrantList


def generateList(allRegistrants, option):
    list = []
    if(option == 'Workshop1'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop A'):
                list.append(registrant)
        return list
    if(option == 'Workshop2'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop B'):
                list.append(registrant)
        return list
    if(option == 'Workshop3'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop C'):
                list.append(registrant)
        return list
    if(option == 'Workshop4'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop D'):
                list.append(registrant)
        return list
    if(option == 'Workshop5'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop E'):
                list.append(registrant)
        return list
    if(option == 'Workshop6'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop F'):
                list.append(registrant)
        return list
    if(option == 'Workshop7'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop G'):
                list.append(registrant)
        return list
    if(option == 'Workshop8'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop H'):
                list.append(registrant)
        return list
    if(option == 'Workshop9'):
        for registrant in allRegistrants:
            if(registrant['session1'] == 'Workshop I'):
              list.append(registrant)
        return list
    if(option == 'mealpack'):
        for registrant in allRegistrants:
            if(registrant['meals'] == 'mealpack'):
                list.append(registrant)
        return list
    if(option == 'dinnerday2'):
        for registrant in allRegistrants:
            if(registrant['meals'] == 'dinnerday2'):
                list.append(registrant)
        return list
    if(option == 'allconference'):
        for registrant in allRegistrants:
            list.append(registrant)
        return list


def generateHTML(registrants, option):
    value = options[option]
    outputfile = open('../src/participantlists/' + option + '.html', 'w')
    frontMatter(outputfile)
    if option == "allconference":
        outputfile.write("<p>Here is the list of all the attendees:</p>\n")
    else:
        outputfile.write("<p>Here is a list of all the attendees who selected: " + value + "</p>\n")
    for registrant in registrants:
        outputfile.write('\t\t\t<p>' + registrant['lastname'] + ',' + registrant['firstname'] + '</p>\n')
    outputfile.write("\n<p>There are a total of: " + str(len(registrants)) + " registrants.</p>\n")
    endMatter(outputfile)
    outputfile.close()


def frontMatter(outputfile):
    outputfile.write('<!DOCTYPE html>\n')
    outputfile.write('<html>\n')
    outputfile.write('<head>\n')
    outputfile.write('\t\t\t\t<meta charset="UTF-8">\n')
    outputfile.write('\t\t\t\t<title>Workshop Registrant Data</title>\n')
    outputfile.write('\t\t\t\t<link href="../css/workshop.css" rel="stylesheet"/>\n')
    outputfile.write('</head>\n')
    outputfile.write('<body>\n')


def endMatter(outputfile):
    outputfile.write('</body>\n')
    outputfile.write('</html>')


allRegistrants = getJSONdata()
allRegistrants.sort(key=itemgetter('lastname'))

for option in options:
    sublist = generateList(allRegistrants, option)
    generateHTML(sublist, option)

