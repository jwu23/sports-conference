csvRegistrants = open('registrant_data.csv', 'r')
tag8 = open('../src/nametags8gen.html', 'w')
tag10 = open('../src/nametags10gen.html', 'w')


def frontMatter():
    tag8.write('<!DOCTYPE html>\n')
    tag8.write('<html lang="en">\n')
    tag8.write('<head>\n')
    tag8.write('\t<meta charset="UTF-8" >\n')
    tag8.write('\t<link href="css/nametags8.css" rel="stylesheet" />\n')
    tag8.write('\t<title>NameTags8Gen</title>\n')
    tag8.write('</head>\n')
    tag8.write('<body>\n')
    tag8.write('</body>\n')

    tag10.write('<!DOCTYPE html>\n')
    tag10.write('<html lang="en">\n')
    tag10.write('<head>\n')
    tag10.write('\t<meta charset="UTF-8" >\n')
    tag10.write('\t<link href="css/nametags10.css" rel="stylesheet" />\n')
    tag10.write('\t<title>NameTags10Gen</title>\n')
    tag10.write('</head>\n')
    tag10.write('<body>\n')
    tag10.write('</body>\n')


def endMatter():
    tag8.write('</html>\n')

    tag10.write('</html>\n')


frontMatter()
count = 0

for csvRegistrant in csvRegistrants.readlines():
    count = count + 1
    registrantData = csvRegistrant.split(',')
    if count % 2 == 1:
        tag8.write('\t\t\t<div class="container">\n')
        tag8.write('\t\t\t\t\t<div class="left">\n')
        tag8.write('\t\t\t\t\t\t\t<p class="firstname">' + registrantData[2] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="lastname">' + registrantData[3] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="position">' + registrantData[12] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="company">' + registrantData[13] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="location">' + registrantData[6] + ', ' + registrantData[7] + '\n')
        tag8.write('\t\t\t\t\t</div>\n')

        tag10.write('\t\t\t<div class="container">\n')
        tag10.write('\t\t\t\t\t<div class="left">\n')
        tag10.write('\t\t\t\t\t\t\t<p class="name">' + registrantData[2] + ' ' + registrantData[3] + '</p>\n')
        tag10.write('\t\t\t\t\t\t\t<p class="position">' + registrantData[12] + '</p>\n')
        tag10.write('\t\t\t\t\t\t\t<p class="company">' + registrantData[13] + '</p>\n')
        tag10.write('\t\t\t\t\t\t\t<p class="location">' + registrantData[6] + ', ' + registrantData[7] + '\n')
        tag10.write('\t\t\t\t\t</div>\n')

    else:
        tag8.write('\t\t\t\t\t<div class="right">\n')
        tag8.write('\t\t\t\t\t\t\t<p class="firstname">' + registrantData[2] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="lastname">' + registrantData[3] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="position">' + registrantData[12] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="company">' + registrantData[13] + '</p>\n')
        tag8.write('\t\t\t\t\t\t\t<p class="location">' + registrantData[6] + ', ' + registrantData[7] + '\n')
        tag8.write('\t\t\t\t\t</div>\n')
        tag8.write('\t\t\t</div>\n')

        tag10.write('\t\t\t\t\t<div class="right">\n')
        tag10.write('\t\t\t\t\t\t\t<p class="name">' + registrantData[2] + ' ' + registrantData[3] + '</p>\n')
        tag10.write('\t\t\t\t\t\t\t<p class="position">' + registrantData[12] + '</p>\n')
        tag10.write('\t\t\t\t\t\t\t<p class="company">' + registrantData[13] + '</p>\n')
        tag10.write('\t\t\t\t\t\t\t<p class="location">' + registrantData[6] + ', ' + registrantData[7] + '\n')
        tag10.write('\t\t\t\t\t</div>\n')
        tag10.write('\t\t\t</div>\n')

endMatter()

csvRegistrants.close()
tag8.close()
tag10.close()
